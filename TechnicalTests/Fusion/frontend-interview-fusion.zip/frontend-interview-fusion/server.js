require('colors');
const jsonServer = require('json-server');
const server = jsonServer.create();
const router = jsonServer.router('db.json');
const middlewares = jsonServer.defaults();

server.use(middlewares);

server.get('/mortgageTypes', (_, res) => {
  const mortgageTypes = router.db.getState().mortgageTypes;
  res.jsonp(mortgageTypes);
});

server.get('/offers/:mortgageType', (req, res) => {
  const { mortgageType: mortgageType } = req.params;

  const sanitisedMortgageType = mortgageType && mortgageType.toUpperCase();
  const offers = router.db.getState().offers;
  const offerWithRates = offers.filter((offer) => offer.mortgageType === sanitisedMortgageType || offer.mortgageType == 'SVR');

  if (!offerWithRates) console.error(`⚠️  Could not find mortgage type: ${sanitisedMortgageType}`);

  res.jsonp(offerWithRates);
});

server.use(router);
const app = server.listen(3002, () => {
  console.log(
    `
  -----  Welcome to the  -----
             NewDay
  -----  Frontend Test  -----

`.brightBlue,
    ' Resources'.bold,
    `\n  http://localhost:${app.address().port}/mortgageTypes`,
    `\n  http://localhost:${app.address().port}/offers`,
    '\n  Home'.bold,
    `\n  http://localhost:${app.address().port}\n`,
  );
});
