import { render, screen } from '@testing-library/react';

import App from './';

describe('<App />', () => {
  it('renders correctly', () => {
    render(<App />);

    const logo = screen.getByTitle('NewDay');
    const subHeading = screen.getByText('Mortgage Offers Exercise');
    const inputs = screen.getAllByRole('textbox');
    const convertButton = screen.getByText('Get Offers');

    expect(logo).toBeInTheDocument();
    expect(subHeading).toBeInTheDocument();
    expect(inputs).toHaveLength(3);
    expect(convertButton).toBeInTheDocument();
  });
});
