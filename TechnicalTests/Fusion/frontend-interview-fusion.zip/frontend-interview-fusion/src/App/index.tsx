import { useState } from 'react';
import styled from 'styled-components';

import { ReactComponent as Logo } from '../assets/logo.svg';
import Input from '../components/Input';
import { palette } from '../styles';
import Button from '../components/Button';

function App() {
  const [propertyValue, setPropertyValue] = useState('');
  const [deposit, setDeposit] = useState('');
  const [term, setTerm] = useState('');

  const getOffers = async () => {
    console.error("Add code here!");
  }

  return (
    <div>
      <StyledHeader>
        <Logo title="NewDay" />
        <p>Mortgage Offers Exercise</p>
      </StyledHeader>
      <ContentContainer>
        <MortgageContainer>
          <Input label="Property value" onChange={(value) => setPropertyValue(value)} value={propertyValue} />
          <Input label="Deposit amount" onChange={(value) => setDeposit(value)} value={deposit} />
          <Input label="Mortgage Term" onChange={(value) => setTerm(value)} value={term} />
          <Button onClick={getOffers} label="Get Offers" />
        </MortgageContainer>
      </ContentContainer>
    </div>
  );
}

const StyledHeader = styled.header`
  height: 280px;
  display: flex;
  flex-flow: column;
  align-items: center;
  justify-content: center;
  background-color: ${palette.black};
  color: ${palette.white};
`;

const ContentContainer = styled.div`
  display: flex;
  justify-content: center;
  align-items: center;
`;

const MortgageContainer = styled.div`
  border-radius: 8px;
  box-shadow:
    0 4px 8px 0 rgba(0, 0, 0, 0.2),
    0 6px 20px 0 rgba(0, 0, 0, 0.2);
  width: 400px;
  margin-top: -50px;
  background-color: ${palette.white};
  padding: 36px 30px;
  // min-height: 100vh;
`;

export default App;
