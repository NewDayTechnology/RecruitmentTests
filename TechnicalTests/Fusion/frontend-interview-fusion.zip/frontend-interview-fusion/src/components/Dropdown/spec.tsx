import { fireEvent, render, screen } from '@testing-library/react';

import Dropdown from './';

describe('<Dropdown />', () => {
  const label = 'This is a select';
  const mockOnChange = jest.fn();
  const optionProps = ['option1', 'option2', 'option3'].map((option) => ({ value: option, label: option }));

  const props = {
    options: optionProps,
    label,
    onChange: mockOnChange,
  };

  it('renders', () => {
    render(<Dropdown {...props} />);

    const select = screen.getByText('This is a select');

    expect(select).toBeInTheDocument();
    expect(select).toHaveTextContent(label);
  });

  it('handles onChange', async () => {
    const { getAllByTestId, getByTestId } = render(<Dropdown {...props} />);

    await fireEvent.change(getByTestId('select'), { target: { value: 'option2' } });
    let options = getAllByTestId('select-option') as HTMLOptionElement[];
    expect(options[0].selected).toBeFalsy();
    expect(options[1].selected).toBeTruthy();
    expect(options[2].selected).toBeFalsy();
    expect(mockOnChange).toHaveBeenCalledTimes(1);
  });
});
