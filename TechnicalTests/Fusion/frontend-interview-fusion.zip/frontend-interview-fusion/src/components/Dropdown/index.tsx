import React from 'react';
import styled from 'styled-components';

type OptionProp = {
  label: string;
  value: string;
};

type DropdownProps = {
  label?: string;
  onChange: (val: string) => void;
  options: OptionProp[];
};

const Dropdown: React.FC<DropdownProps> = ({ label, onChange, options }) => {
  return (
    <Container>
      {label && <StyledLabel>{label}</StyledLabel>}
      <StyledDropdown data-testid="select" onChange={(e) => onChange(e.target.value)}>
        {options.map((option) => (
          <option data-testid="select-option">{option.label}</option>
        ))}
      </StyledDropdown>
    </Container>
  );
};

const Container = styled.div`
  display: flex;
  flex-direction: column;
`;

const StyledLabel = styled.label`
  font-weight: 600;
  margin: 12px 0 8px;
`;

const StyledDropdown = styled.select`
  padding: 16px 8px;
  border: solid 1px rgba(0, 0, 0, 0.2);
  border-radius: 4px;
`;

export default Dropdown;
