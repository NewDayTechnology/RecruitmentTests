import { fireEvent, render, screen } from '@testing-library/react';

import Button from './';

describe('<Button />', () => {
  const label = 'This is a button';
  const mockOnClick = jest.fn();

  const props = {
    label,
    onClick: mockOnClick,
  };

  it('renders', () => {
    const { rerender } = render(<Button {...props} />);

    const button = screen.getByText('This is a button');

    expect(button).toBeInTheDocument();
    expect(button).toHaveTextContent(label);
    expect(button).not.toBeDisabled();

    rerender(<Button {...props} isDisabled />);

    expect(button).toBeDisabled();
  });

  it('handles onClick', async () => {
    const { rerender } = render(<Button {...props} isDisabled />);

    const button = screen.getByRole('button');

    await fireEvent.click(button);
    expect(mockOnClick).toHaveBeenCalledTimes(0);

    rerender(<Button {...props} isDisabled={false} />);

    await fireEvent.click(button);
    expect(mockOnClick).toHaveBeenCalledTimes(1);
  });
});
