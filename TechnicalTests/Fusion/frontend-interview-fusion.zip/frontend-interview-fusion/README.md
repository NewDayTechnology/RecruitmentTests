# NewDay Frontend Interview

## Overview

We'll be pairing on a React application that allows users to search mortgage offers. The application was started by a different team but we are now the owners of it, we would like to:

1. Complete some features/enhancements/bugs collaboratively including making improvements to the UX.
2. Add tests for features and functionality we add
3. Fix any bugs we come across

A project board will be shared with you during the pairing exercise and we will simulate a natural working enviroment. Our goal is to work through the cards on that project board together.

We have been given a [design](design.png) by product which we should use as a guide. They are however open to any UX improvements which would make the experience better for the customer.

Please note that while some bugs have been added on to the project board there may still be more bugs to be found.

## Getting started

You will need the following dependencies:

1. Node.js
2. Git
3. Yarn or NPM

Please come prepared with your preferred working environment, the sooner we get to doing the tickets the better it is for you.

## Running the application

Useful commands to know:

### Start the dev server

Runs the local development server on port 3000.

```console
$ yarn start
```

### Run the API

Runs the local API from a static database:

```console
$ yarn api
```

#### Mortgage Types

List of mortgage types which is used to group certain offers of mortgages.

```
GET - http://localhost:3002/mortgageTypes
```

See db.json `mortgageTypes` node to see what shape they are sent as.

#### Offers

Returns a list of offers which are supported for the given mortgage type requested

```
GET - http://localhost:3002/offers/:mortgageType
```

See db.json `offers` node to see what shape they are sent as.

### Testing

Runs tests via Jest and React Testing Library

```console
$ yarn test
```
